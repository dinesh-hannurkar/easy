package main

import (
	"database/sql"
	"encoding/json"
	"fmt"
	"log"
	"net/http"

	_ "github.com/go-sql-driver/mysql"
	"github.com/gorilla/mux"
)

// Category type
type Category struct {
	CAT   string    `json:"cid"`
	Cname string    `json:"cname"`
	Test  []Product `json:"product"`
}

//Product type
type Product struct {
	ID    string `json:"pid"`
	Title string `json:"title"`
	Desc  string `json:"desc"`
	Brand string `json:"brand"`
	Image string `json:"image"`
	Price string `json:"price"`
}

// var Products []Product
var Categories []Category

var Products []Product

func allProducts(v http.ResponseWriter, r *http.Request) {
	// db, err := sql.Open("mysql", "root:root@tcp(192.168.1.99)/buildmart")
	db, err := sql.Open("mysql", "root:@tcp(127.0.0.1:3306)/buildmart")
	if err != nil {
		panic(err.Error())
	}
	defer db.Close()
	cat, err := db.Query("SELECT id,c_name FROM product_category")
	var cid Category
	var cname Category
	var pid Product
	var title Product
	var desc Product
	var brand Product
	var image Product
	var price Product

	for cat.Next() {

		err = cat.Scan(&cid.CAT, &cname.CAT)

		mainStruct := Category{CAT: cid.CAT, Cname: cname.CAT}

		results, err := db.Query("SELECT products.cat_id,products.p_id,brand.brand_name,products.title,products.details,products.image,products.price from brand,products, product_category where products.cat_id = ? AND product_category.id = products.cat_id AND products.brand_id=brand.brand_id AND products.status='1'", cid.CAT)
		if err != nil {
			panic(err.Error())
		}

		for results.Next() {
			err = results.Scan(&cid.CAT, &pid.ID, &title.Title, &desc.Desc, &brand.Brand, &image.Image, &price.Price)
			if err != nil {
				panic(err.Error())
			}
			// fmt.Println(title.Title)
			// Products = append(Products, Product{ID: pid.ID, Title: title.Title, Desc: desc.Desc, Brand: brand.Brand, Image: image.Image, Price: price.Price})
			w := Product{ID: pid.ID, Title: title.Title, Desc: desc.Desc, Brand: brand.Brand, Image: image.Image, Price: price.Price}
			mainStruct.Test = append(mainStruct.Test, w)
		}

		// js, _ := json.MarshalIndent(mainStruct, "", "  ")
		// fmt.Printf("%s\n", js)
		v.Header().Set("Content-Type", "application/json")
		json.NewEncoder(v).Encode((mainStruct))
	}
}
func api(w http.ResponseWriter, r *http.Request) {
	fmt.Fprintf(w, "Welcome to the HomePage!")
	fmt.Println("Endpoint Hit: homePage")
}
func handleRequests() {
	myRouter := mux.NewRouter().StrictSlash(true)
	myRouter.HandleFunc("/", api)
	myRouter.HandleFunc("/products", allProducts).Methods("GET")
	log.Fatal(http.ListenAndServe("localhost:8000", myRouter))
}
func main() {
	handleRequests()
}
