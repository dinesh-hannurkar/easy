<?php require('header.php');?>
<?php require('squery.php');?>
<div id="hero-area" class="hero-area-bg">
    <div class="container">
        <div class="row">
            <div class="col-lg-7 col-md-12 col-sm-12 col-xs-12">
                <div class="contents">
                    <h2 class="head-title">Our Team<br></h2>
                    <br>
                </div>
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="typewriter wow fadeInUp" data-wow-delay="0.3s">
                    <p>" We are a team of dynamic youngsters stepping into the market to make a mark in this incredibly competitive IT industry.
                        We aim to provide our clients customized utmost satisfaction.
                        To interface knowledge with deliverance, this is what we strive to work for. "
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Hero Area End -->
</header>
<?php require('footer.php');?>
<?php require('script.php');?>
