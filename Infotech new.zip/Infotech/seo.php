<?php require('header.php');?>
<?php require('squery.php');?>
<div id="hero-area" class="hero-area-bg">
    <div class="container">
        <div class="row">
            <div class="col-lg-7 col-md-12 col-sm-12 col-xs-12">
                <div class="contents">
                    <h2 class="head-title">Seo<br></h2>
                    <br>
                </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                <div class="typewriter wow fadeInLeft" data-wow-delay="0.3s">
                    <img src="assets/img/services/seoimage.jpg" alt="Software Development" width="96%">
                </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                <div class="typewriter wow fadeInRight" data-wow-delay="0.3s">
                    <p>Creation and Promotion of a website is a very important and a crucial part of a business. However, you still need to let all those people know that you exist. It is just like having a phone number. You need to give your mobile number to people and list it in the mobile directory before people start calling. Website promotion is a similar procedure for your website.</p><br>
                </div>
            </div><br>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="typewriter wow fadeInUp" data-wow-delay="0.3s">
                    <p>Our Website Promotion (Search Engine Optimization) services brings your website on top rankings in search engines so that your website can beat your competitors website and you can reach your prospective customers.</p><br>
                </div>
            </div><br>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="height:120px;">
                <div class="typewriter wow fadeInRight" data-wow-delay="0.6s">

                </div>
                <br>
            </div>
    </div>
</div>
<!-- Hero Area End -->
</header>
<?php require('footer.php');?>
<?php require('script.php');?>
