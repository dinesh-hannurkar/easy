<?php require('squery.php');?>
<?php require('config.php'); ?>
<!DOCTYPE html>
<html lang="en">
<!--Designed by Dinesh Hannurkar dineshhannurkar20@gmail.com-->

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>Virasat Infotech</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <!-- Icon -->
    <link rel="stylesheet" href="assets/fonts/line-icons.css">
    <!-- Owl carousel -->
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/owl.theme.css">
    <!-- Animate -->
    <link rel="stylesheet" href="assets/css/animate.css">
    <!-- Main Style -->
    <link rel="stylesheet" href="assets/css/main.css">
    <!-- Responsive Style -->
    <link rel="stylesheet" href="assets/css/responsive.css">
    <style>
        .typewriter p {
            color: black;
            font-size: 20px;
            line-height: 30px;
            text-align: justify;
            overflow: hidden;
            margin: 0 auto;
            /* Gives that scrolling effect as the typing happens */
            letter-spacing: .15em;
            /* Adjust as needed */
            animation:
                typing 3.5s steps(30, end),
                blink-caret .5s step-end infinite;
        }

        .dropdown:hover>.dropdown-menu {
            display: block;
        }

        .dropdown>.dropdown-toggle:active {
            /*Without this, clicking will make it sticky*/
            pointer-events: none;
        }

        .navs {
            color: #2471a3;
            font-weight: bold;
            font-size: 20px;
        }

        @media only screen and (width: 786px) {}

        #hero-area2 {
            /*    background-image: url(../img/hero-area.svg);*/
            background-position: center center;
            background-repeat: no-repeat;
            background-size: cover;
            min-height: 650px;
            position: relative;
            overflow: hidden;
            padding: 180px 0 80px;
        }

        #hero-area2 .contents .head-title {
            color: #222222;
            font-size: 42px;
            font-weight: 700;
            line-height: 60px;
            margin-bottom: 10px;
        }

        #hero-area2 .contents .header-button {
            margin-top: 20px;
            color: #222222;
        }

        #hero-area2 .contents .header-button .btn {
            margin-right: 10px;
        }

        .sloder-img {
            background: #34363a;
        }

        label {
            color: black;
        }

        .upload-btn-wrapper {
            position: relative;
            overflow: hidden;
            display: inline-block;
        }

        .btn2 {
            border: 2px solid gray;
            color: gray;
            background-color: white;
            padding: 8px 20px;
            border-radius: 8px;
            font-size: 20px;
            font-weight: bold;
        }

        .upload-btn-wrapper input[type=file] {
            font-size: 100px;
            position: absolute;
            left: 0;
            top: 0;
            opacity: 0;
        }
        .text{
            font-size: 50px;
            line-height:60px;
        }
        @media screen and (max-width:640px) {
         span {
            font-size: 50px;
            font-weight: bold;
            }
            header{
                background-size: 400%;
                background-repeat: no-repeat;
                }
            .text{
                font-size: 25px;
                line-height:30px;
                padding-top: 30px;
                }
            .foot{
                font-size: 25px;
            }
            .foots{
                font-size: 15px;
            }
            }
        
        @media screen and (max-width:1440){
           span {
                font-size: 80px;
                font-weight: bold;
            }
        }
    </style>
</head>

<body>
    <!-- Header Area wrapper Starts -->
    <header id="header-wrap" style="background-image: url('assets/img/services/career.jpg')">
        <!-- Navbar Start -->
        <nav class="navbar navbar-expand-md bg-inverse fixed-top scrolling-navbar">
            <div class="container-fluid">
                <a class="section-title navbar-brand imgs" style="color:#2471a3" href="index.php"><img class="imgs" src="assets/img/logo.png" height="100px" width="330px" alt="VIRASAT INFOTECH"></a>
                <!--                <p class="section-title" style="color:#2471a3"><strong>VIRASAT INFOTECH</strong></p>-->
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="lni-menu"></i>
                </button>
                <div class="collapse navbar-collapse" id="navbarCollapse">
                    <ul class="navbar-nav mr-auto w-100 justify-content-end clearfix">
                        <li class="nav-item active">
                            <div class="dropdown">
                                <button class="btn navs" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" onclick="document.location.href='index.php';" style="color:#2471a3;">
                                    Home
                                </button>
                            </div>
                        </li>

                        <li class="nav-item">
                            <div class="dropdown">
                                <button class="btn navs" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" onclick="document.location.href='#apply';" style="color:#2471a3;">
                                    Apply
                                </button>
                            </div>
                        </li>

                    </ul>
                </div>
            </div>
        </nav>
        <div id="hero-area2" class="hero-area-bg">
            <div class="container">
                <div class="row">
                    <div class="col-lg-7 col-md-12 col-sm-12 col-xs-12">
                        <div class="contents">

                            <br>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                        <div class="typewriter wow fadeInLeft" data-wow-delay="0.3s">

                        </div>
                    </div>
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="wow fadeInRight" data-wow-delay="0.3s">
                            <span style="color:white; font-size:50px"><Strong>Discover,<br><br><br> Apply,<br><br> <br>Learn</Strong></span><br>
                        </div>
                    </div><br>
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="height:370px;">
                        <div class="typewriter wow fadeInRight" data-wow-delay="0.6s">

                        </div>
                        <br>
                    </div>
                </div>
            </div>
        </div>
        <!-- Hero Area End -->
    </header>
    <div id="apply">
        <div class="about-area section-padding bg-gray" id="" style="background-image: url('assets/img/services/resume.png');background-repeat: no-repeat;background-size:100%;">
            <div class="container">
                <div class="section-header text-center">
                    <h2 class="section-title wow fadeInDown" data-wow-delay="0.3s">Apply</h2>
                    <!--                <img src="assets/img/services/resume.png" alt="" width="100%">-->
                </div>

            </div>
            <div class="container">
                <div class="row">
                    <div class="col-lg-9 col-md-9 col-xs-12 info">
                        <label class="text" for="title">UPLOAD YOUR RESUME HERE TO APPLY !</label>
                        <div class="alert alert-danger alert-dismissable">
                            <strong>Note:&nbsp;&nbsp;Upload Only PDF files.</strong>
                            <button type="button" class="close" data-dismiss="alert">×</button>
                        </div>

                    </div>
                    
                    <div class="col-lg-3 col-md-3 col-xs-3 info">
                        <div class="about-wrapper wow fadeInLeft" data-wow-delay="0.3s">
                            <form method="post" enctype="multipart/form-data" style="width:300px">
                                <div class="form-group">
                                    <label for="name">Full Name</label>
                                    <input type="text" name="name" class="form-control" id="name" placeholder="Full Name" required>
                                </div>
                                <div class="form-group">
                                    <label for="email">Email Address</label>
                                    <input type="email" name="email" class="form-control" id="email" placeholder="Email" required>
                                </div>
                                <div class="upload-btn-wrapper">
                                    <button class="btn2">Upload a file</button>
                                    <input type="file" name="file" />
                                </div>
                                <br>
                                <input type="submit" name="submit" value="Send" class="btn btn-primary btn-block">
                            </form>
                        </div>
                    </div>

                </div>

            </div>
        </div>
    </div>
    <?php require('footer.php');?>
    <?php require('script.php');?>
    <?php
    if(isset($_POST['submit']))
    {
//        echo "<script>alert('Yes');</script>";
        $name=$_POST['name'];
        $email=$_POST['email'];

        $targetfolder = "resumes/";

        $targetfolder = $targetfolder . basename( $_FILES['file']['name']) ;

        if(move_uploaded_file($_FILES['file']['tmp_name'], $targetfolder))

        {
            $query="insert into resume(`name`,`email`,`path`) values('$name','$email','$targetfolder')";
            if(mysqli_query($conn,$query))
            {
            echo "The file ". basename( $_FILES['file']['name']). " is uploaded";
            }
        }

        else {

        echo "Problem uploading file";

        }

    }
    ?>
