<style>
    @media screen and (max-width:640px) {
        .typewriter p {
            font-size: 15px;
            font-weight: bold;
        }

    }

</style>
