<?php require('header.php');?>

<!-- Hero Area Start -->
<div id="hero-area" class="hero-area-bg">
    <div class="container">
        <div class="row">
            <div class="col-lg-7 col-md-12 col-sm-12 col-xs-12">
                <div class="contents">
                    <h2 class="head-title">Web Devlopment<br>Application Devlopment<br></h2>
                    <h5>Join Us & Make Your Work Easy...!</h5>
                </div>
            </div>
            <div class="col-lg-5 col-md-12 col-sm-12 col-xs-12">
                <div class="intro-img">
                    <img class="img-fluid" src="assets/img/intros.svg" alt="">
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Hero Area End -->

</header>

</div>
<br><br>
<!--Careers Section End-->
<div class="container">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="typewriter wow fadeInUp" data-wow-delay="0.3s">
                    <p>" Our existence is for providing specific and productive solutions to our clients. We tend to provide State-of-the-Art Solution to our client. We go to the root of the problem and solve it, thereby negating all possibilities of its lingering. Versatility is our niche and customer satisfaction is our goal. "</p>
                </div>
            </div>
</div><br>
<!-- Features Section Start -->
<section id="features" class="section-padding">
    <div class="container">
        <div class="section-header text-center">
            <h2 class="section-title wow fadeInDown" data-wow-delay="0.3s">Awesome Features In Web Development</h2>
            <div class="shape wow fadeInDown" data-wow-delay="0.3s"></div>
        </div>
        <div class="row">
            <div class="col-lg-8 col-md-12 col-sm-12 col-xs-12">
                <div class="content-right">
                    <div class="box-item wow fadeInLeft" data-wow-delay="0.3s">
                        <span class="icon">
                            <i class="lni-rocket"></i>
                        </span>
                        <div class="text">
                            <h4>Mobile Compatibility</h4>
                        </div>
                    </div>

                    <div class="box-item wow fadeInLeft" data-wow-delay="0.6s">
                        <span class="icon">
                            <i class="lni-laptop-phone"></i>
                        </span>
                        <div class="text">
                            <h4>Fully Responsive</h4>
                        </div>
                    </div>
                    <div class="box-item wow fadeInLeft" data-wow-delay="0.9s">
                        <span class="icon">
                            <i class="lni-grid"></i>
                        </span>
                        <div class="text">
                            <h4>Well Planned Information Architecture</h4>
                        </div>
                    </div>

                    <div class="box-item wow fadeInLeft" data-wow-delay="0.15s">
                        <span class="icon">
                            <i class="lni-alarm-clock"></i>
                        </span>
                        <div class="text">
                            <h4>Fast Load Times</h4>
                        </div>
                    </div>
                    <div class="box-item wow fadeInLeft" data-wow-delay="0.18s">
                        <span class="icon">
                            <i class="lni-bug"></i>
                        </span>
                        <div class="text">
                            <h4>Browser Consistency</h4>
                        </div>
                    </div>
                    <div class="box-item wow fadeInLeft" data-wow-delay="0.21s">
                        <span class="icon">
                            <i class="lni-layout"></i>
                        </span>
                        <div class="text">
                            <h4>Effective Navigation</h4>
                        </div>
                    </div>
                    <div class="box-item wow fadeInLeft" data-wow-delay="0.24s">
                        <span class="icon">
                            <i class="lni-target"></i>
                        </span>
                        <div class="text">
                            <h4>Good Error Handling</h4>
                        </div>
                    </div>
                    <div class="box-item wow fadeInLeft" data-wow-delay="0.27s">
                        <span class="icon">
                            <i class="lni-display"></i>
                        </span>
                        <div class="text">
                            <h4>User Friendly</h4>
                        </div>
                    </div>

                </div>
            </div>
            <div id="hide" class="col-lg-4 col-md-12 col-sm-12 col-xs-12" data-wow-delay="0.27s">
                <div class="box-item wow fadeInRight" data-wow-delay="0.80s">
                    <img src="assets/img/feature/banner.jpg" alt="" width="100%">
                </div>
                <div class="content-left">

                </div>
            </div>
        </div>

        <br><br><br>
        <br>
        <!-- Contact Section Start -->

        <!-- Contact Section End -->

        <!-- Footer Section Start -->
        <?php require('footer.php');?>
        <?php require('script.php');?>
