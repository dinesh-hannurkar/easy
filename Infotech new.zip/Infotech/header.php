<!DOCTYPE html>
<html lang="en">
<!--Designed by Dinesh Hannurkar dineshhannurkar20@gmail.com-->
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>Virasat Infotech</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <!-- Icon -->
    <link rel="stylesheet" href="assets/fonts/line-icons.css">
    <!-- Owl carousel -->
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/owl.theme.css">
    <!-- Animate -->
    <link rel="stylesheet" href="assets/css/animate.css">
    <!-- Main Style -->
    <link rel="stylesheet" href="assets/css/main.css">
    <!-- Responsive Style -->
    <link rel="stylesheet" href="assets/css/responsive.css">
    <style>
        .typewriter p {
            color: black;
            font-size: 20px;
            line-height: 30px;
            text-align: justify;
            overflow: hidden;
            margin: 0 auto;
            /* Gives that scrolling effect as the typing happens */
            letter-spacing: .15em;
            /* Adjust as needed */
            animation:
                typing 3.5s steps(30, end),
                blink-caret .5s step-end infinite;
        }
        .dropdown:hover>.dropdown-menu {
        display: block;
        }
        .dropdown>.dropdown-toggle:active {
        /*Without this, clicking will make it sticky*/
        pointer-events: none;
        }
        .navs{
            color: #2471a3;
            font-weight: bold;
            font-size: 20px;
        }
        @media only screen and (width: 786px) {
            
        }
    </style>
</head>

<body>
    <!-- Header Area wrapper Starts -->
    <header id="header-wrap">
        <!-- Navbar Start -->
        <nav class="navbar navbar-expand-md bg-inverse fixed-top scrolling-navbar">
            <div class="container-fluid">
                <a class="section-title navbar-brand imgs" style="color:#2471a3" href="index.php" ><img class="imgs" src="assets/img/logo.png" height="100px" width="330px" alt="VIRASAT INFOTECH"></a>
<!--                <p class="section-title" style="color:#2471a3"><strong>VIRASAT INFOTECH</strong></p>-->
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="lni-menu"></i>
                </button>
                <div class="collapse navbar-collapse" id="navbarCollapse">
                    <ul class="navbar-nav mr-auto w-100 justify-content-end clearfix">
                        <li class="nav-item active">
                            <div class="dropdown">
                                <button class="btn navs" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" onclick="document.location.href='index.php';" style="color:#2471a3;">
                                    Home
                                </button>
                            </div>
                        </li>
                        <li class="nav-item">
                            <div class="dropdown">
                                <button class="btn btn-sm dropdown-toggle navs" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="color:#2471a3;">
                                    Services
                                </button>
                                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                    <a class="dropdown-item" href="web.php" style="color:black">Web Development</a>
                                    <a class="dropdown-item" href="software.php" style="color:black">Software Development</a>
                                    <a class="dropdown-item" href="mobile.php" style="color:black">Mobile Application</a>
                                    <a class="dropdown-item" href="digital.php" style="color:black">Digital Marketing</a>
                                    <a class="dropdown-item" href="graphic.php" style="color:black">Graphic Design</a>
                                    <a class="dropdown-item" href="seo.php" style="color:black">SEO</a>
                                </div>
                            </div>
                        </li>
                        <li class="nav-item">
                                <div class="dropdown">
                                <button class="btn btn-sm dropdown-toggle navs" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="color:#2471a3;">
                                    About Us
                                </button>
                                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                    <a class="dropdown-item" href="./about.php" style="color:black">About Us</a>
                                    <a class="dropdown-item" href="./team.php" style="color:black">Our Team</a>
                                    <a class="dropdown-item" href="./vision.php" style="color:black">Our Vision</a>
                                     <a class="dropdown-item" href="./mission.php" style="color:black">Mission</a>
                                </div>
                            </div>
                        </li>
                        <li class="nav-item">
                            <div class="dropdown">
                                <button class="btn navs" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" onclick="document.location.href='careers.php';" style="color:#2471a3;">
                                    Careers
                                </button>
                            </div>
                        </li>
                        <li class="nav-item">
                            <div class="dropdown">
                                <button class="btn navs" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" onclick="document.location.href='contact.php';" style="color:#2471a3;">
                                    Contact
                                </button>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>