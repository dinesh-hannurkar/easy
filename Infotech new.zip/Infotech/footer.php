<hr>
<footer id="footer" class="footer-area section-padding">
    <div class="container">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 col-mb-12">
                    <div class="widget"><br>
                        <p class="section-title" style="color:#2471a3"><strong>VIRASAT &nbsp;INFOTECH </strong></p>
                        <div class="textwidget">
                            <p class="foot" style="color:gray">Join Us & Make Your Work Easy...!</p>
                        </div><br>
                        <div class="social-icon">
                            <a class="facebook" href="#"><i class="lni-facebook-filled"></i></a>
                            <!--                                 <a class="twitter" href="#"><i class="lni-twitter-filled"></i></a>-->
                            <a class="instagram" href="#"><i class="lni-instagram-filled"></i></a>
                            <!--                                 <a class="linkedin" href="#"><i class="lni-linkedin-filled"></i></a>-->
                        </div>
                    </div>
                </div>

                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <br>
                    <h3 class="section-title">Contact us</h3>
                    <ul class="address">
                        <li>
                            <a href="#"><i class="lni-map-marker"></i>Opposite Indian Oil Petrol Pump, Kanabargi Road,<br>Mahatesh Nagar Belgaum 590016</a>
                        </li>
                        <li>
                            <a href="#"><i class="lni-phone-handset"></i> 0831-4200907</a>
                        </li>
                        <li>
                            <a href="#"><i class="lni-envelope"></i> virasatinfotech@gmail.com</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div id="copyright">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="copyright-content">
                        <p class="foots">Copyright © 2019 | <a rel="nofollow" href="http://virasatinfotech.com/">Virasat Infotech</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
