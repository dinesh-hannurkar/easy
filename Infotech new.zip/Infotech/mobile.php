<?php require('header.php');?>
<?php require('squery.php');?>
<div id="hero-area" class="hero-area-bg">
    <div class="container">
        <div class="row">
            <div class="col-lg-7 col-md-12 col-sm-12 col-xs-12">
                <div class="contents">
                    <h2 class="head-title">Mobile Applications<br></h2>
                    <br>
                </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                <div class="typewriter wow fadeInLeft" data-wow-delay="0.3s">
                    <img src="assets/img/services/Mobile-App-Development.jpg" alt="Software Development" width="80%">
                </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                <div class="typewriter wow fadeInRight" data-wow-delay="0.3s">
                    <p> We have the team of skilled individuals applauded for their transparency, speed, and accuracy in Mobile Application Development. Our team has hands-on knowledge in development of mobile applications and involves very integrally in the design phase and adds value to the end product by doing so.</p><br>
                </div>
            </div><br>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="height:120px;">
                <div class="typewriter wow fadeInRight" data-wow-delay="0.6s">

                </div>
                <br>
            </div>
        </div>
    </div>
</div>
<!-- Hero Area End -->
</header>
<?php require('footer.php');?>
<?php require('script.php');?>
