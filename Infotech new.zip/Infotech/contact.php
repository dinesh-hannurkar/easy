<?php require('header.php');?>

<div id="hero-area" class="hero-area-bg">
    <div class="container">
        <div class="row">
            <div class="col-lg-7 col-md-12 col-sm-12 col-xs-12">
                <div class="contents">
                    <h2 class="head-title">Contact Us<br></h2>
                    <br>
                </div>
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <section id="contact" class="section-padding bg-gray">
                    <div class="container">
                        <div class="row contact-form-area wow fadeInUp" data-wow-delay="0.3s">
                            <div class="col-lg-7 col-md-12 col-sm-12">
                                <div class="contact-block">
                                    <form id="" method="post">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <input type="text" class="form-control" id="name" name="name" placeholder="Name" required>
                                                    <div class="help-block with-errors"></div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <input type="email" placeholder="Email" id="email" class="form-control" name="email" required>
                                                    <div class="help-block with-errors"></div>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <input type="text" placeholder="Subject" id="msg_subject" class="form-control" name="subject" required>
                                                    <div class="help-block with-errors"></div>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <textarea class="form-control" id="message" placeholder="Your Message" rows="7" name="msg" required></textarea>
                                                    <div class="help-block with-errors"></div>
                                                </div>
                                                <div class="submit-button text-left">
                                                    <input type="submit" class="btn btn-common" name="submit" id="form-submit" value="Send Message">
                                                    <div id="msgSubmit" class="h3 text-center hidden"></div>
                                                    <div class="clearfix"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                            <div class="col-lg-5 col-md-12 col-xs-12">
                                <div class="map">
                                    <object style="border:0; height: 280px; width: 100%;" data="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3837.7252861303464!2d74.52907041480523!3d15.871029389003656!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bbf66cc367b1079%3A0xe9cdb6adebdc6945!2sVirast+Realities!5e0!3m2!1sen!2sde!4v1561714427134!5m2!1sen!2sde"></object>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </div>
</div>
<!-- Hero Area End -->
</header>
<?php require('footer.php');?>
<?php require('script.php');?>
<?php
require('config.php');
    if(isset($_POST['submit']))
    {
//        echo "<script>alert('Yes.!');</script>";
        $name=$_POST['name'];
        $email=$_POST['email'];
        $subject=$_POST['subject'];
        $msg=$_POST['msg'];
        
        $query="INSERT INTO `contact_us`(`Name`, `email`, `subject`, `msg`) VALUES ('$name','$email','$subject','$msg')";
        if(mysqli_query($conn,$query))
        {
            echo "<script>alert('Message Sent Successfully.');</script>";
            mysqli_close($conn);
        }
        else
        {
            echo "<script>alert('Please Try Again Later..!');</script>";
            mysqli_close($conn);
        }
        
    }
?>
