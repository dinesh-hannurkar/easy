 <div class="container" style="width:1200px; height:800px;">
     <div id='scroller'>
         <iframe name='myiframe' id='myiframe' src='<?php echo $path2;?>' width='1000px' height='525px'>
         </iframe>
     </div>
     <a href="resume.php"><input type="submit" class="btn btn-info" value="Back"></a>
 </div>
