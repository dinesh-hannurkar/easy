            <a href="#" class="back-to-top">
                <i class="lni-arrow-up"></i>
            </a>

            <!-- Preloader -->
            <div id="preloader">
                <div class="loader" id="loader-1"></div>
            </div>
            <!-- End Preloader -->

            <!-- jQuery first, then Popper.js, then Bootstrap JS -->
            <script src="assets/js/jquery-min.js"></script>
            <script src="assets/js/popper.min.js"></script>
            <script src="assets/js/bootstrap.min.js"></script>
            <script src="assets/js/owl.carousel.min.js"></script>
            <script src="assets/js/wow.js"></script>
            <script src="assets/js/jquery.nav.js"></script>
            <script src="assets/js/scrolling-nav.js"></script>
            <script src="assets/js/jquery.easing.min.js"></script>
            <script src="assets/js/main.js"></script>
            <script src="assets/js/form-validator.min.js"></script>
            <script src="assets/js/contact-form-script.min.js"></script>


            </body>

            </html>