<?php require('header.php');?>
<?php require('squery.php');?>
<div id="hero-area" class="hero-area-bg">
    <div class="container">
        <div class="row">
            <div class="col-lg-7 col-md-12 col-sm-12 col-xs-12">
                <div class="contents">
                    <h2 class="head-title">Our Mission<br></h2>
                    <br>
                </div>
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="typewriter wow fadeInUp" data-wow-delay="0.3s">
                    <p> Create world class value, inspire customers and enable them to thrive, and create an invigorating atmosphere for employees to learn, grow and become the leaders of tomorrow .</p><br>
                </div>
                <div class="typewriter wow fadeInUp" data-wow-delay="0.6s">
                    <p> Enable digital transformation for companies, regardless of size, by providing beyond state-of-the-art applications and platforms, quickly and affordably .</p><br>
                </div>
                <div class="typewriter wow fadeInUp" data-wow-delay="0.9s">
                    <p> Digitalize companies with powerful technology, tools and platforms to become future proof .</p><br>
                </div>
                <div class="typewriter wow fadeInUp" data-wow-delay="1.2s">
                    <p> To Deliver GREAT Value to our Customers, Employees as well as the Society with the help of new Idea's & Technology .</p><br>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Hero Area End -->
</header>
<?php require('footer.php');?>
<?php require('script.php');?>
