<?php require('header.php');?>
<?php require('squery.php');?>
<div id="hero-area" class="hero-area-bg">
    <div class="container">
        <div class="row">
            <div class="col-lg-7 col-md-12 col-sm-12 col-xs-12">
                <div class="contents">
                    <h2 class="head-title">Digital Marketing<br></h2>
                    <br>
                </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                <div class="typewriter wow fadeInLeft" data-wow-delay="0.3s">
                    <img src="assets/img/services/digital%20marketing.jpg" alt="Software Development" width="96%">
                </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                <div class="typewriter wow fadeInRight" data-wow-delay="0.3s">
                    <p> E-Advertisement, also called as Internet advertising, uses the internet to deliver the promotional marketing messages to consumers. It includes email marketing, social media marketing and mobile advertising. Like other advertising media.</p><br>
                </div>
            </div><br>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="height:120px;">
                <div class="typewriter wow fadeInRight" data-wow-delay="0.6s">

                </div>
                <br>
            </div>
        </div>
    </div>
</div>
<!-- Hero Area End -->
</header>
<?php require('footer.php');?>
<?php require('script.php');?>
