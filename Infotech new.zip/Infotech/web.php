<?php require('header.php');?>
<?php require('squery.php');?>
<div id="hero-area" class="hero-area-bg">
    <div class="container">
        <div class="row">
            <div class="col-lg-7 col-md-12 col-sm-12 col-xs-12">
                <div class="contents">
                    <h2 class="head-title">Web Development<br></h2>
                    <br>
                </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                <div class="typewriter wow fadeInLeft" data-wow-delay="0.3s">
                    <img src="assets/img/services/web-development.jpg" alt="Web Development" width="100%">
                </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                <div class="typewriter wow fadeInRight" data-wow-delay="0.3s">
                    <p > Today business tactics have been changed, online presence is became key factor for every business irrespective of its size, it is an unsaid rule, that if your business is progressive enough, it is bound to have a website of its own.</p><br>
                </div><br>
            </div>
               <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="height:250px;">
                <div class="typewriter wow fadeInRight" data-wow-delay="0.6s">
                    <p> Website is the best way to enrich progress of your business by customizing communication strategy for target audience and also to generate generic information about potential customer.</p><br>
                </div><br>
            </div>
        </div>
    </div>
</div>
<br>
<section >
   <div class="container">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="typewriter wow fadeInLeft" data-wow-delay="0.3s">
            <p>1. Our team makes effective use of the latest designing, website development, maintenance tools for the benefit of the client's representation on the World Wide Web </p><br>
        </div>
        <div class="typewriter wow fadeInLeft" data-wow-delay="0.6s">
            <p>2. Our team of expert designers and developers work with same enthusiasm to develop all type of websites like simple static website, event management website, matrimony website, retails website to e-commerce website. </p><br>
        </div>
        <div class="typewriter wow fadeInLeft" data-wow-delay="0.9s">
            <p>3. Our team focuses on optimized content, graphics, designs and other light weight elements in order to craft an interactive platform which attracts more targeted customers. </p><br>
        </div>
        <div class="typewriter wow fadeInLeft" data-wow-delay="1.2s">
            <p>4. We make the best utilization of web based tools to deliver custom web designswhich make effective use of flash, and other such designing techniques which will benefit your internet marketing objectives. </p><br>
        </div><br>
    </div>
    </div>
</section>
<!-- Hero Area End -->
</header>
<?php require('footer.php');?>
<?php require('script.php');?>
