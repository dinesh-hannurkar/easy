<?php require('header.php');?>
<?php require('squery.php');?>
<div id="hero-area" class="hero-area-bg">
    <div class="container">
        <div class="row">
            <div class="col-lg-7 col-md-12 col-sm-12 col-xs-12">
                <div class="contents">
                    <h2 class="head-title">Software Development<br></h2>
                    <br>
                </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                <div class="typewriter wow fadeInLeft" data-wow-delay="0.3s">
                    <img src="assets/img/services/software-development.jpg" alt="Software Development" width="100%">
                </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                <div class="typewriter wow fadeInRight" data-wow-delay="0.3s">
                    <p> We know and understand our customer's requirements, the worldly software security needs, and continuing support to delivered customized software. We provide consulting and development maintenance services. We have great technical expertise in all business domains.</p><br>
                </div>
            </div><br>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="height:200px;">
                <div class="typewriter wow fadeInRight" data-wow-delay="0.6s">
                    <p> Do you have an idea ? We have the technology. Bring your idea to reality and get a customized product developed.</p><br>
                </div>
                <br>
            </div>
        </div>
    </div>
</div>
<!-- Hero Area End -->
</header>
<?php require('footer.php');?>
<?php require('script.php');?>
