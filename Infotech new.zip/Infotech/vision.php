<?php require('header.php');?>
<?php require('squery.php');?>
<div id="hero-area" class="hero-area-bg">
    <div class="container">
        <div class="row">
            <div class="col-lg-7 col-md-12 col-sm-12 col-xs-12">
                <div class="contents">
                    <h2 class="head-title">Our Vision<br></h2>
                    <br>
                </div>
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="typewriter wow fadeInUp" data-wow-delay="0.3s">
                    <p>1. To reach that position where one can look up to us .</p><br>
                </div>
                <div class="typewriter wow fadeInUp" data-wow-delay="0.6s">
                    <p>2. To create qualitative and positive environment for growth .</p><br>
                </div>
                <div class="typewriter wow fadeInUp" data-wow-delay="0.9s">
                    <p>3. To empower other capable people who deserve a chance in this industry .</p><br>
                </div>
                <div class="typewriter wow fadeInUp" data-wow-delay="1.2s">
                    <p>4. Build innovative products using latest technology that are easy to use and have rich functionality .</p><br>
                </div>
                <div class="typewriter wow fadeInUp" data-wow-delay="1.5s">
                    <p>5. Become a global leader in the digital space by transforming the landscape of business enterprises through continuous innovation and collaboration .</p><br>
                </div>
                <div class="typewriter wow fadeInUp" data-wow-delay="1.8s">
                    <p>6. Through digital innovation, simplify and improve the quality of work life to create a better world for individuals, consumers and organizations .</p><br>
                </div>
                <div class="typewriter wow fadeInUp" data-wow-delay="2.1s">
                    <p>7. We aim to Become an Ecosystem (IT Company) around unique Idea's and Inventions to help EVERYONE .</p><br>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Hero Area End -->
</header>
<?php require('footer.php');?>
<?php require('script.php');?>
