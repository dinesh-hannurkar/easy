U1456168
Husain Patel
Django

** Hotel App **

Current Features:

1. View Hotels
2. View Hotel Details
3. View Hotel Rooms
4. Add New Hotels
5. Add Rooms to hotels
6. Add Images to hotels
7. Add and delete images & edit hotels
8. Edit and delete rooms
9. Delete Hotels
10. User can send Partner Proposal to admin
11. Admin can Accept or Decline Partner proposal
12. Authorization , admin / partner/ user can access different parts of the site.
13. Hotels are owned by Partners
14. Advanced Search for Hotels
15. Users can book Reservations
16 Charts for partners to view statistics
17. Users are recommended nearby hotels
18. Star Rating System
19. Weather API , Live Weather
20. Login With Google Authentication
21. Login with Twitter Authentication
Upcoming Features:
