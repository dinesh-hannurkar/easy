from django.apps import AppConfig

class HotelappConfig(AppConfig):
    name = 'HotelApp'
