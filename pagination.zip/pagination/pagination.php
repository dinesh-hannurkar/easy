<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Pagination</title>
    <meta name="description" content="Bootstrap.">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    
    <script src="js/jquery.min.js"></script>
    <link rel="stylesheet" href="css/jquery.dataTables.min.css">
    <script type="text/javascript" src="js/jquery.dataTables.min.js"></script>
</head>

<body style="margin:20px auto">
    <div class="container">
        <div class="row header" style="text-align:center;color:green">
            <h3>Pagination</h3>
        </div>
        <table id="myTable" class="table table-striped">
            <thead>
                <tr>
                    <th>ENO</th>
                    <th>EMPName</th>
                    <th>Country</th>
                    <th>Salary</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>001</td>
                    <td>Anusha</td>
                    <td>India</td>
                    <td>10000</td>
                </tr>
                <tr>
                    <td>002</td>
                    <td>Charles</td>
                    <td>United Kingdom</td>
                    <td>28000</td>
                </tr>
                <tr>
                    <td>003</td>
                    <td>Sravani</td>
                    <td>Australia</td>
                    <td>7000</td>
                </tr>
                <tr>
                    <td>004</td>
                    <td>Amar</td>
                    <td>India</td>
                    <td>18000</td>
                </tr>
                <tr>
                    <td>005</td>
                    <td>Lakshmi</td>
                    <td>India</td>
                    <td>12000</td>
                </tr>
                <tr>
                    <td>006</td>
                    <td>James</td>
                    <td>Canada</td>
                    <td>50000</td>
                </tr>

                <tr>
                    <td>007</td>
                    <td>Ronald</td>
                    <td>US</td>
                    <td>75000</td>
                </tr>
                <tr>
                    <td>008</td>
                    <td>Mike</td>
                    <td>Belgium</td>
                    <td>100000</td>
                </tr>
                <tr>
                    <td>009</td>
                    <td>Andrew</td>
                    <td>Argentina</td>
                    <td>45000</td>
                </tr>

                <tr>
                    <td>010</td>
                    <td>Stephen</td>
                    <td>Austria</td>
                    <td>30000</td>
                </tr>
                <tr>
                    <td>011</td>
                    <td>Sara</td>
                    <td>China</td>
                    <td>750000</td>
                </tr>
                <tr>
                    <td>012</td>
                    <td>JonRoot</td>
                    <td>Argentina</td>
                    <td>65000</td>
                </tr>
            </tbody>
        </table>
    </div>
</body>
<script>
    $(document).ready(function() {
        $('#myTable').dataTable();
    });
</script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</html>