<!--03 July 2019 Developed by Dinesh Hannurkar-->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Virasat Infotech</title>
    <!-- Pagination -->
    <script src="assets/js/jquery.min.js"></script>
    <link rel="stylesheet" href="assets/css/jquery.dataTables.min.css">
    <script type="text/javascript" src="assets/js/jquery.dataTables.min.js"></script>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <!-- Animate -->
    <link rel="stylesheet" href="assets/css/animate.css">
    <!-- Main Style -->
    <link rel="stylesheet" href="assets/css/main.css">
    <!-- Responsive Style -->
    <link rel="stylesheet" href="assets/css/responsive.css">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/GrayGrids/LineIcons/LineIcons.css">
</head>

<body class="career-body" style="">
    <!-- Header Area wrapper Starts -->
    <header id="header-wrap">
        <!-- Navbar Start -->
        <nav class="navbar navbar-expand-md bg-light fixed-top scrolling-navbar">
            <div class="container">
                <!--                                  <a class="section-title" style="color:#2471a3" href="index.html" class="navbar-brand"><img src="assets/img/logo.jpg" height="50px" width="350px" alt="VIRASAT INFOTECH"></a>-->
                <p class="section-title v" style="color:#2471a3">VIRASAT INFOTECH </p>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="lni-menu"></i>
                </button>
                <div class="collapse navbar-collapse" id="navbarCollapse">
                    <ul class="navbar-nav mr-auto w-100 justify-content-end clearfix">
                        <li class="nav-item">
                            <a class="nav-link" href="logout.php">
                                Logout
                            </a>
                        </li>
                        <li class="nav-item active">
                            <a class="nav-link" href="logout.php">
                                ADMIN
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <div id="hero" class="">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="contents">
                            <div class="container">
                                <?php
                                            require('config.php');
                                    $query="SELECT * FROM `contact_us` order by time desc";
                                    $res=mysqli_query($conn,$query);
                                        ?>
                                <div class="row">
                                    <div class="table-responsive display">
                                        <table id="myTable" class="table table-striped table-bordered">
                                            <thead>
                                                <tr>
                                                    <th>Name</th>
                                                    <th>Email</th>
                                                    <th>Subject</th>
                                                    <th>Message</th>
                                                    <th>Date / Time</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php 
                                    while($row=mysqli_fetch_array($res))
                                    {

                                        echo "<tr>";
                                        echo "<td>" .$row['Name']. "</td>";
                                        echo "<td>" .$row['email']. "</td>";
                                        echo "<td>" .$row['subject']. "</td>";
                                        echo "<td>" .$row['msg']. "</td>";
                                        echo "<td>" .$row['time']. "</td>";
                                        echo "</tr>";

                                    }
                                    ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <script>
        $(document).ready(function() {
            $('#myTable').dataTable();
        });
    </script>
    <script src="assets/js/main.js"></script>

    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/wow.js"></script>
    <script src="assets/js/jquery.nav.js"></script>
    <script src="assets/js/scrolling-nav.js"></script>
    <script src="assets/js/jquery.easing.min.js"></script>
    <script src="assets/js/main.js"></script>
    <script src="assets/js/form-validator.min.js"></script>
    <script src="assets/js/contact-form-script.min.js"></script>
</body>

</html>