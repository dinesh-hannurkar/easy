<?php 
require('config.php');
?>
<!--Designed by Dinesh Hannurkar dineshhannurkar20@gmail.com-->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Admin Login</title>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/main.css">
</head>

<body class="login">
    <div class="container-fluid set" style="width:340px ">
        <form class="form-fluid" style="width:300px" method="post">
            <div class="form-group">
                <label for="header"><strong>ADMIN LOGIN</strong></label><br><br>
                <label class="set2" for="username">Username</label>
                <input type="text" class="form-control text" name="user" id="username" placeholder="Username" required>
            </div>
            <div class="form-group">
                <label class="set2" for="pass">Password</label>
                <input type="password" class="form-control text" name="pass" id="pass" placeholder="Password" required>
            </div>
            <input type="submit" class="btn btn-primary btn-block" value="Login" name="login">
        </form>
    </div>

    <script src="assets/js/jquery-min.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>

</body>

</html>
<?php
    if(isset($_POST['login']))
    {
         $username = $_POST['user'];
         $password = $_POST['pass'];

         $query = "SELECT * from `admin` WHERE username = '$username' AND password = '$password'";
         $res = mysqli_query($conn,$query);
        $row = mysqli_num_rows($res);
         if (!$row == 1) {
         echo "<script>alert('Invalid Username OR Password..!');</script>";
         } else {
             echo "<script>alert('Logged in successfully.');</script>";
             session_start();

             // Storing session data
             $_SESSION["name"] = $username;
             header('Location:careers.php');

        }
    }
?>
