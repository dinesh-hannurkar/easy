<!DOCTYPE html>
<html lang="en">
<!--Designed by Dinesh Hannurkar dineshhannurkar20@gmail.com-->
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>Virasat Infotech</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <!-- Icon -->
    <link rel="stylesheet" href="assets/fonts/line-icons.css">
    <!-- Owl carousel -->
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/owl.theme.css">

    <!-- Animate -->
    <link rel="stylesheet" href="assets/css/animate.css">
    <!-- Main Style -->
    <link rel="stylesheet" href="assets/css/main.css">
    <!-- Responsive Style -->
    <link rel="stylesheet" href="assets/css/responsive.css">
</head>

<body>

    <!-- Header Area wrapper Starts -->
    <header id="header-wrap">
        <!-- Navbar Start -->
        <nav class="navbar navbar-expand-md bg-inverse fixed-top scrolling-navbar">
            <div class="container">
                <!--                                  <a class="section-title" style="color:#2471a3" href="index.html" class="navbar-brand"><img src="assets/img/logo.jpg" height="50px" width="350px" alt="VIRASAT INFOTECH"></a>-->
                <p class="section-title" style="color:#2471a3"><strong>VIRASAT INFOTECH</strong></p>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="lni-menu"></i>
                </button>
                <div class="collapse navbar-collapse" id="navbarCollapse">
                    <ul class="navbar-nav mr-auto w-100 justify-content-end clearfix">
                        <li class="nav-item active">
                            <a class="nav-link" href="#hero-area">
                                Home
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#services">
                                Services
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#about">
                                About Us
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#career">
                                Careers
                            </a>
                        </li>

                        <!--
                         <li class="nav-item">
                             <a class="nav-link" href="#testimonial">
                                 Testimonial
                             </a>
                         </li>
-->
                        <li class="nav-item">
                            <a class="nav-link" href="#contact">
                                Contact
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <!-- Navbar End -->

        <!-- Hero Area Start -->
        <div id="hero-area" class="hero-area-bg">
            <div class="container">
                <div class="row">
                    <div class="col-lg-7 col-md-12 col-sm-12 col-xs-12">
                        <div class="contents">
                            <h2 class="head-title">Web Devlopment<br>Application Devlopment<br></h2>
                            <h5>Join Us & Make Your Work Easy...!</h5>
                            <!--
                             <div class="header-button">
                                 <a href="#" class="btn btn-common">Download Now</i></a>
                                 <a href="#" class="btn btn-border video-popup">Learn More</i></a>
                             </div>
-->
                        </div>
                    </div>
                    <div class="col-lg-5 col-md-12 col-sm-12 col-xs-12">
                        <div class="intro-img">
                            <img class="img-fluid" src="assets/img/intros.svg" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Hero Area End -->

    </header>
    <!-- Header Area wrapper End -->

    <!-- Services Section Start -->
    <section id="services" class="section-padding">
        <div class="container">
            <div class="section-header text-center">
                <h2 class="section-title wow fadeInDown" data-wow-delay="0.3s">Our Services</h2>
                <div class="shape wow fadeInDown" data-wow-delay="0.3s"></div>
            </div>
            <div class="row">
                <!-- Services item -->
                <div class="col-md-6 col-lg-4 col-xs-12">
                    <div class="services-item wow fadeInRight" data-wow-delay="0.3s">
                        <img src="assets/img/feature/web.jpg" alt="" width="100%">

                        <div class="services-content">
                            <h3><a href="#">Web Devlopment</a>
                                <div class="icon">
                                    <i class="lni-rocket"></i>
                                </div>
                            </h3>
                        </div>
                    </div>
                </div>
                <!-- Services item -->
                <div class="col-md-6 col-lg-4 col-xs-12">
                    <div class="services-item wow fadeInRight" data-wow-delay="0.6s">
                        <img src="assets/img/feature/SEO.jpg" alt="" width="100%">
                        <div class="services-content">
                            <h3><a href="#">SEO</a>
                                <div class="icon">
                                    <i class="lni-chrome"></i>
                                </div>
                            </h3>
                        </div>
                    </div>
                </div>
                <!-- Services item -->
                <div class="col-md-6 col-lg-4 col-xs-12">
                    <div class="services-item wow fadeInRight" data-wow-delay="0.9s">
                        <img src="assets/img/feature/digital%20marketing.png" alt="" width="100%">
                        <div class="services-content">
                            <h3><a href="#">Digital Marketing</a>
                                <div class="icon">
                                    <i class="lni-users"></i>
                                </div>
                            </h3>
                        </div>
                    </div>
                </div>
                <!-- Services item -->
                <div class="col-md-6 col-lg-4 col-xs-12">
                    <div class="services-item wow fadeInRight" data-wow-delay="1.2s">
                        <img src="assets/img/feature/UIUX.jpg" alt="" width="100%">
                        <div class="services-content">
                            <h3><a href="#">UI/UX Design</a>
                                <div class="icon">
                                    <i class="lni-layers"></i>
                                </div>
                            </h3>
                        </div>
                    </div>
                </div>
                <!-- Services item -->
                <div class="col-md-6 col-lg-4 col-xs-12">
                    <div class="services-item wow fadeInRight" data-wow-delay="1.5s">
                        <img src="assets/img/feature/App-Development.jpg" alt="" width="100%">
                        <div class="services-content">
                            <h3><a href="#">App Development</a>
                                <div class="icon">
                                    <i class="lni-mobile"></i>
                                </div>
                            </h3>
                       </div>
                    </div>
                </div>
                <!-- Services item -->
                <div class="col-md-6 col-lg-4 col-xs-12">
                    <div class="services-item wow fadeInRight" data-wow-delay="1.8s">
                        <img src="assets/img/feature/User-Friendly-Interface.png" alt="" width="100%">
                        <div class="services-content">
                            <h3><a href="#">User Friendly interface</a>
                                <div class="icon">
                                    <i class="lni-display"></i>
                                </div>
                            </h3>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Services Section End -->

    <!-- About Section start -->
    <div class="about-area section-padding bg-gray" id="about">
        <div class="container">
            <div class="section-header text-center">
                <h2 class="section-title wow fadeInDown" data-wow-delay="0.3s">About Us</h2><br>
                <h2 class="section-title wow fadeInDown" data-wow-delay="0.3s">Join Us & Make Your Work Easy...!</h2>
                <div class="shape wow fadeInDown" data-wow-delay="0.3s"></div>
            </div>
            <div class="col-lg-12 col-md-12 col-xs-12 info">
                <img src="assets/img/about/Web.jpg" alt="" width="100%">
            </div>
        </div>
        <br><br>
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-12 col-xs-12 info">
                    <div class="about-wrapper wow fadeInLeft" data-wow-delay="0.3s">
                        <div>
                            <div class="site-heading">
                                <h2 class="section-title">Keep Detailed Statistics of your Company</h2>
                            </div>
                            <div class="content">
                                <a href="#" class="btn btn-common mt-3">Read More</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-12 col-xs-12 wow fadeInRight" data-wow-delay="0.3s">
                    <img class="img-fluid" src="assets/img/about/img.png" alt="">
                </div>
            </div>
        </div>
    </div>
    <!-- About Section End -->

    <!--Careers Section Start-->
    <div class="about-area section-padding bg-gray" id="career">
        <div class="container">
            <div class="section-header text-center">
                <h2 class="section-title wow fadeInDown" data-wow-delay="0.3s">Walk in Interview </h2>
                <div class="shape wow fadeInDown" data-wow-delay="0.3s"></div>
            </div>

        </div>
        <br><br>
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-6 col-xs-3 info">
                    <div class="about-wrapper wow fadeInLeft" data-wow-delay="0.3s">
                        <img src="assets/img/Careers/php-svgrepo-com.svg" alt="" width="100%"><br>
                        <br>
                        <h5 class="text-center">PHP Developers</h5>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-xs-3 info">
                    <div class="about-wrapper wow fadeInLeft" data-wow-delay="0.6s">
                        <img src="assets/img/Careers/graphic-design-svgrepo-com.svg" alt="" width="100%"><br>
                        <br>
                        <h5 class="text-center">UI/UX Designers</h5>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-xs-3 info">
                    <div class="about-wrapper wow fadeInRight" data-wow-delay="0.6s">
                        <img src="assets/img/Careers/java-svgrepo-com.svg" alt="" width="100%"><br>
                        <br>
                        <h5 class="text-center">JAVA Developers</h5>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-xs-3 info">
                    <div class="about-wrapper wow fadeInRight" data-wow-delay="0.3s">
                        <img src="assets/img/Careers/android-svgrepo-com.svg" alt="" width="100%"><br>
                        <br>
                        <h5 class="text-center">ANDROID Developers</h5>
                    </div>
                </div>
            </div>
            <div class="section-header text-center">
                <br>
                <h2 class="section-title wow fadeInDown" data-wow-delay="0.15s">Send your resume at - virasatrealities@gmail.com</h2>
                <div class="shape wow fadeInDown" data-wow-delay="0.3s"></div>
            </div>
        </div>
    </div>
    <!--Careers Section End-->

    <!-- Features Section Start -->
    <section id="features" class="section-padding">
        <div class="container">
            <div class="section-header text-center">
                <h2 class="section-title wow fadeInDown" data-wow-delay="0.3s">Awesome Features In Web Development</h2>
                <div class="shape wow fadeInDown" data-wow-delay="0.3s"></div>
            </div>
            <div class="row">
                <div class="col-lg-8 col-md-12 col-sm-12 col-xs-12">
                    <div class="content-right">
                        <div class="box-item wow fadeInLeft" data-wow-delay="0.3s">
                            <span class="icon">
                                <i class="lni-rocket"></i>
                            </span>
                            <div class="text">
                                <h4>Mobile Compatibility</h4>
                            </div>
                        </div>

                        <div class="box-item wow fadeInLeft" data-wow-delay="0.6s">
                            <span class="icon">
                                <i class="lni-laptop-phone"></i>
                            </span>
                            <div class="text">
                                <h4>Fully Responsive</h4>
                            </div>
                        </div>
                        <div class="box-item wow fadeInLeft" data-wow-delay="0.9s">
                            <span class="icon">
                                <i class="lni-grid"></i>
                            </span>
                            <div class="text">
                                <h4>Well Planned Information Architecture</h4>
                            </div>
                        </div>

                        <div class="box-item wow fadeInLeft" data-wow-delay="0.15s">
                            <span class="icon">
                                <i class="lni-alarm-clock"></i>
                            </span>
                            <div class="text">
                                <h4>Fast Load Times</h4>
                            </div>
                        </div>
                        <div class="box-item wow fadeInLeft" data-wow-delay="0.18s">
                            <span class="icon">
                                <i class="lni-bug"></i>
                            </span>
                            <div class="text">
                                <h4>Browser Consistency</h4>
                            </div>
                        </div>
                        <div class="box-item wow fadeInLeft" data-wow-delay="0.21s">
                            <span class="icon">
                                <i class="lni-layout"></i>
                            </span>
                            <div class="text">
                                <h4>Effective Navigation</h4>
                            </div>
                        </div>
                        <div class="box-item wow fadeInLeft" data-wow-delay="0.24s">
                            <span class="icon">
                                <i class="lni-target"></i>
                            </span>
                            <div class="text">
                                <h4>Good Error Handling</h4>
                            </div>
                        </div>
                        <div class="box-item wow fadeInLeft" data-wow-delay="0.27s">
                            <span class="icon">
                                <i class="lni-display"></i>
                            </span>
                            <div class="text">
                                <h4>User Friendly</h4>
                            </div>
                        </div>

                    </div>
                </div>
                <div id="hide" class="col-lg-4 col-md-12 col-sm-12 col-xs-12" data-wow-delay="0.27s">
                    <div class="box-item wow fadeInRight" data-wow-delay="0.80s">
                        <img src="assets/img/feature/banner.jpg" alt="" width="100%">
                    </div>
                    <div class="content-left">

                    </div>
                </div>
            </div>

            <br><br><br>
            <br>
            <!-- Call To Action Section Start -->

            <!-- Contact Section Start -->
            <section id="contact" class="section-padding bg-gray">
                <div class="container">
                    <div class="section-header text-center">
                        <h2 class="section-title wow fadeInDown" data-wow-delay="0.3s">Contact Us</h2>
                        <div class="shape wow fadeInDown" data-wow-delay="0.3s"></div>
                    </div>
                    <div class="row contact-form-area wow fadeInUp" data-wow-delay="0.3s">
                        <div class="col-lg-7 col-md-12 col-sm-12">
                            <div class="contact-block">
                                <form id="" method="post">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <input type="text" class="form-control" id="name" name="name" placeholder="Name" required>
                                                <div class="help-block with-errors"></div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <input type="email" placeholder="Email" id="email" class="form-control" name="email" required>
                                                <div class="help-block with-errors"></div>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <input type="text" placeholder="Subject" id="msg_subject" class="form-control" name="subject" required>
                                                <div class="help-block with-errors"></div>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <textarea class="form-control" id="message" placeholder="Your Message" rows="7" name="msg" required></textarea>
                                                <div class="help-block with-errors"></div>
                                            </div>
                                            <div class="submit-button text-left">
                                                <input type="submit" class="btn btn-common" name="submit" id="form-submit" value="Send Message">
                                                <div id="msgSubmit" class="h3 text-center hidden"></div>
                                                <div class="clearfix"></div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <div class="col-lg-5 col-md-12 col-xs-12">
                            <div class="map">
                                <object style="border:0; height: 280px; width: 100%;" data="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3837.7252861303464!2d74.52907041480523!3d15.871029389003656!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bbf66cc367b1079%3A0xe9cdb6adebdc6945!2sVirast+Realities!5e0!3m2!1sen!2sde!4v1561714427134!5m2!1sen!2sde"></object>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- Contact Section End -->

            <!-- Footer Section Start -->
            <footer id="footer" class="footer-area section-padding">
                <div class="container">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 col-mb-12">
                                <div class="widget"><br>
                                    <p class="section-title" style="color:#2471a3"><strong>VIRASAT &nbsp;INFOTECH </strong></p>
                                    <div class="textwidget">
                                        <p style="color:gray">Join Us & Make Your Work Easy...!</p>
                                    </div><br>
                                    <div class="social-icon">
                                        <a class="facebook" href="#"><i class="lni-facebook-filled"></i></a>
                                        <!--                                 <a class="twitter" href="#"><i class="lni-twitter-filled"></i></a>-->
                                        <a class="instagram" href="#"><i class="lni-instagram-filled"></i></a>
                                        <!--                                 <a class="linkedin" href="#"><i class="lni-linkedin-filled"></i></a>-->
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                <br>
                                <h3 class="section-title">Contact</h3>
                                <ul class="address">
                                    <li>
                                        <a href="#"><i class="lni-map-marker"></i>Opposite Indian Oil Petrol Pump, Kanabargi Road,<br>Mahatesh Nagar Belgaum 590016</a>
                                    </li>
                                    <li>
                                        <a href="#"><i class="lni-phone-handset"></i> 0831-4200907</a>
                                    </li>
                                    <li>
                                        <a href="#"><i class="lni-envelope"></i> virasatinfotech@gmail.com</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="copyright">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="copyright-content">
                                    <p>Copyright © 2019 | <a rel="nofollow" href="#">Virasat Infotech</a></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </footer>
            <!-- Footer Section End -->

            <!-- Go to Top Link -->
            <a href="#" class="back-to-top">
                <i class="lni-arrow-up"></i>
            </a>

            <!-- Preloader -->
            <div id="preloader">
                <div class="loader" id="loader-1"></div>
            </div>
            <!-- End Preloader -->

            <!-- jQuery first, then Popper.js, then Bootstrap JS -->
            <script src="assets/js/jquery-min.js"></script>
            <script src="assets/js/popper.min.js"></script>
            <script src="assets/js/bootstrap.min.js"></script>
            <script src="assets/js/owl.carousel.min.js"></script>
            <script src="assets/js/wow.js"></script>
            <script src="assets/js/jquery.nav.js"></script>
            <script src="assets/js/scrolling-nav.js"></script>
            <script src="assets/js/jquery.easing.min.js"></script>
            <script src="assets/js/main.js"></script>
            <script src="assets/js/form-validator.min.js"></script>
            <script src="assets/js/contact-form-script.min.js"></script>

</body>

</html>
<?php
require('config.php');
    if(isset($_POST['submit']))
    {
//        echo "<script>alert('Yes.!');</script>";
        $name=$_POST['name'];
        $email=$_POST['email'];
        $subject=$_POST['subject'];
        $msg=$_POST['msg'];
        
        $query="INSERT INTO `contact_us`(`Name`, `email`, `subject`, `msg`) VALUES ('$name','$email','$subject','$msg')";
        if(mysqli_query($conn,$query))
        {
            echo "<script>alert('Message Sent Successfully.');</script>";
            mysqli_close($conn);
        }
        else
        {
            echo "<script>alert('Please Try Again Later..!');</script>";
            mysqli_close($conn);
        }
        
    }
?>
